package AE03;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
//cree la clase amb els objectes de la clase
public class Llibre {
int id;
String titol;
String autor;
int any;
String editorial;
int pagines;
//cree el constructor
public Llibre(int ids,String tit,String aut,int anyo,String edi,int pag){
	id=ids;
	titol=tit;
	autor=aut;
	any=anyo;
	editorial=edi;
	pagines=pag;}
//crear getters setters y getters
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getTitol() {
	return titol;
}
public void setTitol(String titol) {
	this.titol = titol;
}
public String getAutor() {
	return autor;
}
public void setAutor(String autor) {
	this.autor = autor;
}
public int getAny() {
	return any;
}
public void setAny(int any) {
	this.any = any;
}
public String getEditorial() {
	return editorial;
}
public void setEditorial(String editorial) {
	this.editorial = editorial;
}
public int getPagines() {
	return pagines;
}
public void setPagines(int pagines) {
	this.pagines = pagines;
}

}
