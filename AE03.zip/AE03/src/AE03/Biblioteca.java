package AE03;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
 
public class Biblioteca {
	//cree un scanner per a llegir la informaci� pasada per teclat del usuari
	static Scanner x= new Scanner(System.in);
	//cree un int per a posar l'ultim id
	static int ultId=0;
	//crear una funci� que carga un array amb la informaci� del archiu xml
    public static ArrayList<Llibre> recuperarTots(){
    // Se crea un Document build pera llegir y pasar la informacio
    	DocumentBuilderFactory dbFactory =DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder;
    //Se crea un array de llibres
        ArrayList<Llibre> llista= new ArrayList<Llibre>();
        try {
 
            dBuilder = dbFactory.newDocumentBuilder();
            Document doc =dBuilder.parse(new File("biblio.xml"));
            Element origen = doc.getDocumentElement();
            NodeList nodeList = doc.getElementsByTagName("llibre");
   //Se afegix als atributs la informaci�
        for ( int i=0; i<nodeList.getLength();i++) {
            Node node = nodeList.item(i);
            if(node.getNodeType() == Node.ELEMENT_NODE) {
                Element elemento = (Element) node;
                String id= elemento.getAttribute("id");
                String tit=elemento.getElementsByTagName("titol").item(0).getTextContent();
                String aut=elemento.getElementsByTagName("autor").item(0).getTextContent();
                String anyo=elemento.getElementsByTagName("any").item(0).getTextContent();
                String edi=elemento.getElementsByTagName("editorial").item(0).getTextContent();
                String pag=elemento.getElementsByTagName("pagines").item(0).getTextContent();
   //Se crea el constructor
                Llibre lib = new Llibre(Integer.parseInt(id),tit,aut,Integer.parseInt(anyo),edi,Integer.parseInt(pag));
   //Se afegix el llibre
                llista.add(lib);
                ultId=Integer.parseInt(id);}}
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();}
        return llista;}
   //Se pasa un llibre i es mostra la informaci�
    public static void mostrarLlibre(Llibre llibre) {
	    System.out.println("ID: "+llibre.getId());
	    System.out.println("Titol: "+llibre.getTitol());
	    System.out.println("Autor: "+llibre.getAutor());
	    System.out.println("Any: "+llibre.getAny());
	    System.out.println("Editorial: "+llibre.getEditorial());
	    System.out.println("Pagina "+llibre.getPagines());}
  //Se pasa un llibre i es mostra la informaci� 
    public static void mostrarLlibres(Llibre llibre) {
	    System.out.println("ID: "+llibre.getId());
	    System.out.println("Titol: "+llibre.getTitol());
}
    //retorna un llibre amb la id que li dones
    public static Llibre recuperarLlibre(int ids) {
    	//carga l'array
        ArrayList<Llibre>llista=recuperarTots();
        //se recorre la llista hasta encontar l'id
        for(int i =0;i<llista.size();i++) {
            if(ids==llista.get(i).getId()) {
        //se retorna el llibre
            	return llista.get(i);}
        }
        return null;
    }
    //Es un metod pera pasar la informaci� del array al fitxer xml
    public static int writeXmlFile(ArrayList<Llibre> llista) {
    	try{
    	DocumentBuilderFactory dFact= DocumentBuilderFactory.newInstance();
    	DocumentBuilder build= dFact.newDocumentBuilder();
    	Document doc= build.newDocument();
    	Element raiz= doc.createElement("biblioteca");
    	doc.appendChild(raiz);
    	for(Llibre lib: llista) {
    	Element llibre= doc.createElement("llibre");
    	String id= String.valueOf(lib.getId());
    	llibre.setAttribute("id",id); raiz.appendChild(llibre);
    	Element titol= doc.createElement("titol");
    	titol.appendChild(doc.createTextNode(String.valueOf(lib.getTitol())));
    	llibre.appendChild(titol);
    	Element autor= doc.createElement("autor");
    	autor.appendChild(doc.createTextNode(String.valueOf(lib.getAutor())));
    	llibre.appendChild(autor);
    	Element any= doc.createElement("any");
    	any.appendChild(doc.createTextNode(String.valueOf(lib.getAny())));
    	llibre.appendChild(any);
    	Element editorial= doc.createElement("editorial");
    	editorial.appendChild(doc.createTextNode(String.valueOf(lib.getEditorial())));
    	llibre.appendChild(editorial);
    	Element pagines= doc.createElement("pagines");
    	pagines.appendChild(doc.createTextNode(String.valueOf(lib.getPagines())));
    	llibre.appendChild(pagines);
    	}
    	TransformerFactory tranFactory= TransformerFactory.newInstance(); // Crear serializador
    	Transformer aTransformer= tranFactory.newTransformer();
    	aTransformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1"); // Darle formato al documento
    	aTransformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
    	aTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
    	DOMSource source= new DOMSource(doc);
    	try{
    	FileWriter fw= new FileWriter("biblio.xml");// Definir el nombre del fichero y guardar
    	StreamResult result= new StreamResult(fw);
    	aTransformer.transform(source, result);
    	fw.close();
    	} catch(Exception e) {
    	e.printStackTrace();
    	}
    	} catch(TransformerException ex) {
    	System.out.println("Error escribiendo el documento");
    	} catch(ParserConfigurationException ex) {
    	System.out.println("Error construyendo el documento");
    	}
		return 0;
    	}
    public static int crearLlibre(Llibre llibre) {
    	//carga l'array
    	ArrayList<Llibre> llista=recuperarTots();
    	//afegix el llibre
    	llista.add(llibre);
    	//sobrescriu el xml amb la nova informaci�
    	writeXmlFile(llista);
    	return llista.size();
    }
    public static void borrarLlibre(int ids){
    	//carga l'array
    	ArrayList<Llibre> llista=recuperarTots();
    	//borra el llibre
    	llista.remove(ids-1);
    	//sobrescriu el xml amb la nova informaci�
    	writeXmlFile(llista);}
    public static void  modificarLlibre(int ids) {
    	//carga l'array
    	ArrayList<Llibre> llista=recuperarTots();
    	//Edita la informacio del atribut del objecte
    	System.out.println("Titol: ");
 	   String tit= x.nextLine();
 	   llista.get(ids-1).titol=tit;
        System.out.println("Autor: ");
        String aut= x.nextLine();
        llista.get(ids-1).autor=aut;
        System.out.println("Any: ");
        int anyo= Integer.parseInt(x.nextLine());
        llista.get(ids-1).any=anyo;
        System.out.println("Editorial: ");
        String edi= x.nextLine();
        llista.get(ids-1).editorial=edi;
        System.out.println("Pagines: ");
        int pag= Integer.parseInt(x.nextLine());
    	llista.get(ids-1).pagines=pag;
    	//sobrescriu el xml amb la nova informaci�
    	writeXmlFile(llista);
    }
    public static void main(String[] args) {
    	for(int q=0;q!=-1;q++) {
    	//mostra el menu
       System.out.println("1. Mostrar tots els t�tols de la biblioteca");
       System.out.println("2. Mostrar informaci� detallada d�un llibre");
       System.out.println("3. Crear nou llibre");
       System.out.println("4. Actualitzar llibre");
       System.out.println("5. Borrar llibre");
       System.out.println("6. Tanca la biblioteca"); 
     //carga l'array
       ArrayList<Llibre> llista=recuperarTots();
       int respu = Integer.parseInt(x.nextLine());       
       //amb el nombre pasat selecciona el que vol fer
       switch(respu){
       case 1:
    	  //recorre la llista i mostra tots els llibres
        for(int i=0;i<llista.size();i++) {
            mostrarLlibres(llista.get(i));}
    	   break;
       case 2:
    	   //busca el llibre amb el id i el mostra
    	   System.out.println("Dime el id del libro");
    	   int libro= Integer.parseInt(x.nextLine());    	  
    	   mostrarLlibre(recuperarLlibre(libro));
    	   break;
       case 3: 
    	   //demana informaci� crea el llibre i despres el afegix al array i al xml
    	   System.out.println("Titol: ");
    	   String tit= x.nextLine();
           System.out.println("Autor: ");
           String aut= x.nextLine();
           System.out.println("Any: ");
           int anyo= Integer.parseInt(x.nextLine());
           System.out.println("Editorial: ");
           String edi= x.nextLine();
           System.out.println("Pagines: ");
           int pag= Integer.parseInt(x.nextLine());
           Llibre lib = new Llibre(llista.size()+1,tit,aut,anyo,edi,pag);
    	  int num=crearLlibre(lib);
    	  System.out.println("El id es "+num);
    	   break;
       case 4:
    	   //amb el id que li dones te pedira l'informaci� que vols i el cambia en l'array i el xml
    	   System.out.println("Id que modificar: ");
           int id= Integer.parseInt(x.nextLine());
           modificarLlibre(id);
    	   break;
       case 5:
    	   // amb el id borra l'arxiu en l'array i el xml
    	   System.out.println("Id que borrar: ");
           int ids= Integer.parseInt(x.nextLine());
           borrarLlibre(ids);
    	   break;
       case 6:
    	   //tanca la biblioteca
    	   System.out.println("ADEU!!");
    	   System.exit(0);
    	   break;
    	default: System.out.println("Numero Incorrecto");
       }}
       
    	
    }
 
}
