package AE04;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Digitalizacio {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		/*S'introdueix la ruta del arxiu i se conecta la base de dades. S'introdueix la informaci� de arxiu en la bese de dades*/
		try {
			String ruta= "Dades.csv";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ae04","root","");
		Statement stmt= con.createStatement();
		PreparedStatement insertar= con.prepareStatement("INSERT INTO llibre (titol,autor,any_autor,any,editorial,pag) VALUES (?,?,?,?,?,?)");
		File csv = new File(ruta);
		FileReader fr =new FileReader(csv);
		BufferedReader br = new BufferedReader(fr);
		String linea = br.readLine();
		String[] contenidoFichero;
		int i=1;
	
		while(linea!=null) {
		linea = br.readLine();	
		if(linea!=null) {
		contenidoFichero =linea.split(";");
			
		insertar.setString(1,contenidoFichero[0]);
		insertar.setString(2,contenidoFichero[1]);
		if(contenidoFichero[2]=="") {
			contenidoFichero[2]="NC";
			insertar.setString(3,contenidoFichero[2]);
		}else { insertar.setString(3,contenidoFichero[2]);}
		insertar.setInt(4,Integer.parseInt(contenidoFichero[3]));
		insertar.setString(5,contenidoFichero[4]);
		insertar.setInt(6,Integer.parseInt(contenidoFichero[5]));
		
		insertar.executeUpdate();
		i++;
		}
	
		
		}
	}catch(Exception e){e.printStackTrace();}
		Statement stmt;
		/*Es fan les consultes conectant altra vegada amb la base de dades  */
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ae04","root","");
			stmt = con.createStatement();
			ResultSet rs= stmt.executeQuery("SELECT `titol`, `autor`, `any` FROM `llibre` WHERE `any_autor` <1950;");
			while(rs.next()) {
				System.out.println(rs.getString(1) + " " +rs.getString(2) + " "+rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ae04","root","");
			stmt = con.createStatement();
			ResultSet rs= stmt.executeQuery("SELECT `editorial` FROM llibre WHERE `any` > 2000");
			while(rs.next()) {
				System.out.println(rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
}
