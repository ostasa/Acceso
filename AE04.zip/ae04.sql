-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-11-2021 a las 18:45:45
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ae04`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llibre`
--

CREATE TABLE `llibre` (
  `id` int(11) NOT NULL,
  `titol` varchar(64) NOT NULL,
  `autor` varchar(64) NOT NULL,
  `any_autor` varchar(5) NOT NULL,
  `any` int(11) NOT NULL,
  `editorial` varchar(32) NOT NULL,
  `pag` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `llibre`
--

INSERT INTO `llibre` (`id`, `titol`, `autor`, `any_autor`, `any`, `editorial`, `pag`) VALUES
(20359, 'El señor de los anillos', 'J.R.R. Tolkien', '1890', 1950, 'Minotauro', 1392),
(20360, 'El juego de Ender', 'Orson Scott Card', '1951', 1977, 'Ediciones B', 509),
(20361, 'Lazarillo de Tormes', 'Anónimo', 'NC', 1554, 'Clásicos Populares', 150),
(20362, 'Las uvas de la ira', 'John Steinbeck', '1902', 1939, 'Alianza', 619),
(20363, 'Watchmen', 'Alan Moore', '1953', 1980, 'ECC', 416),
(20364, 'La hoguera de las vanidades', 'Tom Wolfe', '1930', 1980, 'Anagrama', 636),
(20365, 'La familia de Pascual Duarte', 'Camilo José Cela', '1916', 1942, 'Destino', 165),
(20366, 'El señor de las moscas', 'William Golding', '1911', 1972, 'Alianza', 236),
(20367, 'La ciudad de los prodigios', 'Eduardo Mendoza', '1943', 1986, 'Seix Barral', 541),
(20368, 'Ensayo sobre la ceguera', 'José Saramago', '1922', 1995, 'Santillana', 439),
(20369, 'Los surcos del azar', 'Paco Roca', '1969', 2013, 'Astiberri', 349),
(20370, 'Ghosts of Spain', 'Giles Tremlett', '1962', 2006, 'Faber & Faber', 468),
(20371, 'Sidi', 'Arturo Pérez Reverte', '1951', 2019, 'Penguin', 369),
(20372, 'Dune', 'Frank Herbert', '1920', 1965, 'Acervo', 741),
(20373, 'El señor de los anillos', 'J.R.R. Tolkien', '1890', 1950, 'Minotauro', 1392),
(20374, 'El juego de Ender', 'Orson Scott Card', '1951', 1977, 'Ediciones B', 509),
(20375, 'Lazarillo de Tormes', 'Anónimo', 'NC', 1554, 'Clásicos Populares', 150),
(20376, 'Las uvas de la ira', 'John Steinbeck', '1902', 1939, 'Alianza', 619),
(20377, 'Watchmen', 'Alan Moore', '1953', 1980, 'ECC', 416),
(20378, 'La hoguera de las vanidades', 'Tom Wolfe', '1930', 1980, 'Anagrama', 636),
(20379, 'La familia de Pascual Duarte', 'Camilo José Cela', '1916', 1942, 'Destino', 165),
(20380, 'El señor de las moscas', 'William Golding', '1911', 1972, 'Alianza', 236),
(20381, 'La ciudad de los prodigios', 'Eduardo Mendoza', '1943', 1986, 'Seix Barral', 541),
(20382, 'Ensayo sobre la ceguera', 'José Saramago', '1922', 1995, 'Santillana', 439),
(20383, 'Los surcos del azar', 'Paco Roca', '1969', 2013, 'Astiberri', 349),
(20384, 'Ghosts of Spain', 'Giles Tremlett', '1962', 2006, 'Faber & Faber', 468),
(20385, 'Sidi', 'Arturo Pérez Reverte', '1951', 2019, 'Penguin', 369),
(20386, 'Dune', 'Frank Herbert', '1920', 1965, 'Acervo', 741),
(20387, 'El señor de los anillos', 'J.R.R. Tolkien', '1890', 1950, 'Minotauro', 1392),
(20388, 'El juego de Ender', 'Orson Scott Card', '1951', 1977, 'Ediciones B', 509),
(20389, 'Lazarillo de Tormes', 'Anónimo', 'NC', 1554, 'Clásicos Populares', 150),
(20390, 'Las uvas de la ira', 'John Steinbeck', '1902', 1939, 'Alianza', 619),
(20391, 'Watchmen', 'Alan Moore', '1953', 1980, 'ECC', 416),
(20392, 'La hoguera de las vanidades', 'Tom Wolfe', '1930', 1980, 'Anagrama', 636),
(20393, 'La familia de Pascual Duarte', 'Camilo José Cela', '1916', 1942, 'Destino', 165),
(20394, 'El señor de las moscas', 'William Golding', '1911', 1972, 'Alianza', 236),
(20395, 'La ciudad de los prodigios', 'Eduardo Mendoza', '1943', 1986, 'Seix Barral', 541),
(20396, 'Ensayo sobre la ceguera', 'José Saramago', '1922', 1995, 'Santillana', 439),
(20397, 'Los surcos del azar', 'Paco Roca', '1969', 2013, 'Astiberri', 349),
(20398, 'Ghosts of Spain', 'Giles Tremlett', '1962', 2006, 'Faber & Faber', 468),
(20399, 'Sidi', 'Arturo Pérez Reverte', '1951', 2019, 'Penguin', 369),
(20400, 'Dune', 'Frank Herbert', '1920', 1965, 'Acervo', 741),
(20401, 'El señor de los anillos', 'J.R.R. Tolkien', '1890', 1950, 'Minotauro', 1392),
(20402, 'El juego de Ender', 'Orson Scott Card', '1951', 1977, 'Ediciones B', 509),
(20403, 'Lazarillo de Tormes', 'Anónimo', 'NC', 1554, 'Clásicos Populares', 150),
(20404, 'Las uvas de la ira', 'John Steinbeck', '1902', 1939, 'Alianza', 619),
(20405, 'Watchmen', 'Alan Moore', '1953', 1980, 'ECC', 416),
(20406, 'La hoguera de las vanidades', 'Tom Wolfe', '1930', 1980, 'Anagrama', 636),
(20407, 'La familia de Pascual Duarte', 'Camilo José Cela', '1916', 1942, 'Destino', 165),
(20408, 'El señor de las moscas', 'William Golding', '1911', 1972, 'Alianza', 236),
(20409, 'La ciudad de los prodigios', 'Eduardo Mendoza', '1943', 1986, 'Seix Barral', 541),
(20410, 'Ensayo sobre la ceguera', 'José Saramago', '1922', 1995, 'Santillana', 439),
(20411, 'Los surcos del azar', 'Paco Roca', '1969', 2013, 'Astiberri', 349),
(20412, 'Ghosts of Spain', 'Giles Tremlett', '1962', 2006, 'Faber & Faber', 468),
(20413, 'Sidi', 'Arturo Pérez Reverte', '1951', 2019, 'Penguin', 369),
(20414, 'Dune', 'Frank Herbert', '1920', 1965, 'Acervo', 741);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `llibre`
--
ALTER TABLE `llibre`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `llibre`
--
ALTER TABLE `llibre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20415;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
